---
bookCollapseSection: true
---

# Section

Section renders pages in section as definition list, using title and description.

## Example

```tpl
{{</* section */>}}
```

{{<section>}}
